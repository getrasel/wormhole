




$(window).load(function() {
  $(".loader").delay(200).fadeIn("slow");
  $(".loader").delay(2000).fadeOut("slow");
});

$('#wormholeCanvas').load(function(){
    this.addClass("slow");
  });