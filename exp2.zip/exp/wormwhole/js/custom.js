




$(".wormwhole_Iframe").load(function() {
  $(".wormwhole_Iframe").addClass('Iframe_Zindex');
});
