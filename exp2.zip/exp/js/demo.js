/**
 * demo.js
 * http://www.codrops.com
 *
 * Licensed under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 * 
 * Copyright 2017, Codrops
 * http://www.codrops.com
 * additions by Dave Hansen Solutions
 */
{
	setTimeout(() => document.body.classList.add('render'), 10);

	imagesLoaded('.glitch__img', { background: true }, () => {
		document.body.classList.remove('loading');
		document.body.classList.add('imgloaded');
	});
    setTimeout(function () {
        window.location.href = "index1.php";
        window.clearTimeout(tID);		// clear time out.
    }, 8000);
}